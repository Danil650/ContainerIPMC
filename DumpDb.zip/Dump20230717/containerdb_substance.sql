-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: containerdb
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `substance`
--

DROP TABLE IF EXISTS `substance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `substance` (
  `Id` varchar(200) NOT NULL,
  `Passport` varchar(200) NOT NULL,
  `SubstName` varchar(200) NOT NULL,
  `CAS` text,
  `Meaning` text,
  `Mass` decimal(10,4) NOT NULL,
  `UnitId` int NOT NULL,
  `SubsCreateDate` date DEFAULT NULL,
  `Formula` text,
  `Investigated` tinyint(1) NOT NULL,
  `Left` tinyint(1) NOT NULL,
  `URL` text,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `SubstName_UNIQUE` (`SubstName`),
  KEY `Subst_Unit_idx` (`UnitId`),
  KEY `Subst_Inv_idx` (`Passport`),
  CONSTRAINT `Subst_Inv` FOREIGN KEY (`Passport`) REFERENCES `invoice` (`IdInvoce`),
  CONSTRAINT `Subst_Unit` FOREIGN KEY (`UnitId`) REFERENCES `unit_type` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `substance`
--

LOCK TABLES `substance` WRITE;
/*!40000 ALTER TABLE `substance` DISABLE KEYS */;
INSERT INTO `substance` VALUES ('453f76fc-598d-cae0-3d37-cd9117c970b0','123','Basketanes','5603-27-1','Нормальное',0.9000,2,'2023-05-08','C10H12',1,1,'https://ru.abcdef.wiki/wiki/Basketane'),('84c7a906-10be-33eb-b897-259740579338','123','Acetylcarnitine','14992-62-2','',1.0500,2,'2023-05-08','C9H17NO4',1,1,''),('a546d1a2-1c82-1a96-e6c1-f7a1c49f88a1','123','Barrelene','123','',0.1000,2,'2023-05-08','C8H8',1,1,'https://ru.abcdef.wiki/wiki/Barrelene'),('b38e2b50-3a48-58bf-d03f-2a4b7a416401','123','12-(Acetoxy)stearic acid, 2,3-bis(acetoxy)propyl ester','330198-91-9','',1.0500,1,'2023-05-30','C27H48O8',1,1,''),('d5f8bd68-3b32-f8e5-beea-97dbb953a9a6','43242','Benzaldehyde','100-52-7','',10.0000,1,'2023-05-31','C6H5CHO',1,1,'');
/*!40000 ALTER TABLE `substance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-17 17:00:52
